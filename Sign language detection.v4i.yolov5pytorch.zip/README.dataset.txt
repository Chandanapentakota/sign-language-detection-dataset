# Sign language detection  > 2024-12-12 3:15pm
https://universe.roboflow.com/chandanas-workspace/sign-language-detection-nygkw

Provided by a Roboflow user
License: CC BY 4.0

